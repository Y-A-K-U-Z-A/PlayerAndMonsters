package repositories;

import models.players.interfaces.Player;
import repositories.interfaces.PlayerRepository;

import java.util.ArrayList;
import java.util.List;

public class PlayerRepositoryImpl implements PlayerRepository {
    private List<Player> players;

    public PlayerRepositoryImpl() {
        this.players = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return players.size();
    }

    @Override
    public List<Player> getPlayers() {
        return this.players;
    }

    @Override
    public void add(Player player) {
        if (player == null){
            throw new IllegalArgumentException("Player cannot be null");
        }else {
            for (Player player1 : players) {
                if (player1.getUsername().equals(player.getUsername())){
                    throw new IllegalArgumentException("Player " + player.getUsername() + " already exists!" );
                }
            }
            players.add(player);
        }
    }

    @Override
    public boolean remove(Player player) {
        if (player == null){
            throw new IllegalArgumentException("Player cannot be null");
        }
        players.remove(player);
        return true;
    }

    @Override
    public Player find(String name) {
        for (Player player : players) {
            if (player.getUsername().equals(name)){
                return player;
            }
        }
        return null;
    }
}
