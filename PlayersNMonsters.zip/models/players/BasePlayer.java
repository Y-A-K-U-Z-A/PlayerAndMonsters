package models.players;

import common.ConstantMessages;
import models.players.interfaces.Player;
import repositories.interfaces.CardRepository;

public abstract class BasePlayer implements Player {
    private String username;
    private int health;
    private CardRepository cardRepository;
    private boolean isDead;

    protected BasePlayer(CardRepository cardRepository, String username, int health ) {
        this.setUsername(username);
        this.setHealth(health);
        this.cardRepository = cardRepository;
        isDead = false;
    }



    @Override
    public CardRepository getCardRepository() {
        return this.cardRepository;
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public int getHealth() {
        return this.health;
    }



    @Override
    public boolean isDead() {
        return isDead;
    }

    @Override
    public void takeDamage(int damagePoints) {
        if (damagePoints < 0 ){
            throw new IllegalArgumentException("Damage points cannot be less than zero.");
        }
        this.health = Math.max(this.health - damagePoints, 0);
        this.isDead = this.health == 0;
    }

    @Override
    public void setHealth(int healthPoints) {
        if (healthPoints < 0 ){
            throw new IllegalArgumentException("Player's health bonus cannot be less than zero.");
        }else {
            this.health = healthPoints;
        }
    }
    private void setUsername(String username) {
        if (username == null || username.trim().isEmpty()){
            throw new IllegalArgumentException("Player's username cannot be null or an empty string.");
        }else {
            this.username = username;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(
                String.format(ConstantMessages.PLAYER_REPORT_INFO, this.getUsername(),
                        this.getHealth(),
                        this.getCardRepository().getCount()));
        return sb.toString();
    }
}
