package models.battleFields;

import models.battleFields.interfaces.Battlefield;
import models.cards.interfaces.Card;
import models.players.Beginner;
import models.players.interfaces.Player;

public class BattleFieldImpl implements Battlefield {
    @Override
    public void fight(Player attacker, Player enemy) {
        if (attacker.isDead() || enemy.isDead()){
        throw new IllegalArgumentException("Player is dead!");
        }

        if (attacker instanceof Beginner) {
            this.addBonusStatus(attacker);
        }
        if (enemy instanceof Beginner){
            this.addBonusStatus(enemy);
        }


        increaseHealth(attacker);
        increaseHealth(enemy);

        while (!attacker.isDead() && !enemy.isDead()){
            int attackerDamage = getDeckDamage(attacker);
            int enemyDamage = getDeckDamage(enemy);

            enemy.takeDamage(attackerDamage);
            if (enemy.isDead()){
                break;
            }
            attacker.takeDamage(enemyDamage);
        }

    }

    private int getDeckDamage(Player player) {
        return player.getCardRepository().getCards()
                .stream()
                .mapToInt(Card::getDamagePoints)
                .sum();
    }

    private void addBonusStatus(Player player) {
        player.setHealth(player.getHealth()+40);

        player.getCardRepository().getCards().forEach(c ->{
           c.setDamagePoints(c.getDamagePoints() + 30);
        });
    }

    private void increaseHealth(Player player) {
        for (Card card : player.getCardRepository().getCards()) {
            player.setHealth(player.getHealth() + card.getHealthPoints());
        }
    }
}
