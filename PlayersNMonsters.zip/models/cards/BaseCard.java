package models.cards;

import models.cards.interfaces.Card;

public abstract class BaseCard implements Card {
    private String name;
    private int damagePoints;
    private int healthPoints;

    protected BaseCard(String name, int damagePoints, int healthPoints) {
        this.setName(name);
        this.setDamagePoints(damagePoints);
        this.setHealthPoints(healthPoints);
    }


    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getDamagePoints() {
        return damagePoints;
    }


    @Override
    public int getHealthPoints() {
        return healthPoints;
    }

    private void setName(String name) {
        if (name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException("Card's name cannot be null or an empty string.");
        }else {
            this.name = name;
        }
    }


    @Override
    public void setDamagePoints(int damagePoints) {
        if (damagePoints < 0){
            throw new IllegalArgumentException("Card's damage points cannot be less than zero.");
        }else {
            this.damagePoints = damagePoints;
        }
    }

    private void setHealthPoints(int healthPoints) {
        if (healthPoints < 0){
            throw new IllegalArgumentException("Card's HP cannot be less than zero.");
        }else {
            this.healthPoints = healthPoints;
        }
    }
}
