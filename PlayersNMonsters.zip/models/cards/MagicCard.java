package models.cards;

public class MagicCard extends BaseCard {
    public MagicCard(String name) {
        super(name, 5, 80);
    }
}
