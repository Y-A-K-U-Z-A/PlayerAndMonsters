package models.cards;

public class TrapCard extends BaseCard{
    public TrapCard(String name) {
        super(name, 120, 5);
    }
}
