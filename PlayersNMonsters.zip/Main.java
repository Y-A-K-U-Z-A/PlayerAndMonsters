import core.ManagerControllerImpl;
import core.interfaces.ManagerController;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    String line = sc.nextLine();
    ManagerController mng = new ManagerControllerImpl();

    while (!line.equals("Exit")){
        String[] tokens = line.split("\\s+");
        try{
        switch (tokens[0]){
            case "AddPlayer":
                System.out.println(mng.addPlayer(tokens[1], tokens[2]));
                break;
            case "AddCard":
                System.out.println(mng.addCard(tokens[1], tokens[2]));
                break;
            case "AddPlayerCard":
                System.out.println(mng.addPlayerCard(tokens[1], tokens[2]));
                break;
            case "Fight":
                System.out.println(mng.fight(tokens[1], tokens[2]));
                break;
            case "Report":
                System.out.println(mng.report());
                break;
        }
        }catch (Exception e){
            System.out.println(e.getMessage());
            line = sc.nextLine();
            continue;
        }



        line = sc.nextLine();
    }

    }
}
